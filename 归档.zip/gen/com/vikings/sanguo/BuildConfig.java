/** Automatically generated file. DO NOT MODIFY */
package com.vikings.sanguo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}